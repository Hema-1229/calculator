let memory = 0;

function appendToDisplay(value) {
  document.getElementById("display").value += value;
}

function clearDisplay() {
  document.getElementById("display").value = "";
}

function calculate() {
  try {
    let expression = document.getElementById("display").value
      .replace(/√/g, 'Math.sqrt')
      .replace(/%/g, '*0.01')
      .replace(/\^/g, '**');
    const result = eval(expression);
    document.getElementById("display").value = result;
  } catch (e) {
    document.getElementById("display").value = "Error";
  }
}

function memoryRecall() {
  document.getElementById("display").value += memory;
}

function deleteEachItem() {
  let displayValue = document.getElementById("display").value;
  document.getElementById("display").value = displayValue.slice(0, -1);
}
